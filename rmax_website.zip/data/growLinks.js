import {

    Sparkles,

    Users,
 
    MessageSquare,
  
  } from "lucide-react";

const growLinks = [
    { label: "AI Marketing Tools", icon: <Sparkles className="w-5 h-5" /> },
    { label: "Social Media Integration", icon: <MessageSquare className="w-5 h-5" /> },
    { label: "CRM", icon: <Users className="w-5 h-5" /> },
  ];

export default growLinks